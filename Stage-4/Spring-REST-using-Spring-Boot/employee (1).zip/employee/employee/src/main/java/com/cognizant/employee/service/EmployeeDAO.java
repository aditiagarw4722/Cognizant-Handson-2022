package com.cognizant.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cognizant.employee.model.Employee;

@Component
public class EmployeeDAO {

	static ArrayList<Employee> EMPLOYEE_LIST = new ArrayList<>();
	
	public EmployeeDAO() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		ArrayList<Employee> employees = context.getBean("employeeList", ArrayList.class);
		this.EMPLOYEE_LIST = employees;
	}
	
	public ArrayList<Employee> getAllEmployee(){
		return this.EMPLOYEE_LIST;
	}
}
