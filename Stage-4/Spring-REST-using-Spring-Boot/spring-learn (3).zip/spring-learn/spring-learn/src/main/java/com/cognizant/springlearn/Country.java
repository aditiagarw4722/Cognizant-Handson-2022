package com.cognizant.springlearn;

import org.slf4j.Logger;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.slf4j.LoggerFactory;

public class Country {

	Logger logger = (Logger) LoggerFactory.getLogger(Country.class);
	
	@NotNull
    @Size(min=2, max=2, message="Country code should be 2 characters")
	String code;
	String name;
	
	public Country() {
		super();
		logger.debug("INSIDE COUNTRY CONSTRUCTOR");
	}

	public String getCode() {
		logger.debug("Inside get code");
		return code;
	}

	public void setCode(String code) {
		logger.debug("Inside set code");
		this.code = code;
	}

	public String getName() {
		logger.debug("Inside get name");
		return name;
	}

	public void setName(String name) {
		logger.debug("Inside set code");
		this.name = name;
	}

	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}
	
	
	
	
}
