package com.cognizant.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class SpringLearnApplication {
	
	static Logger logger = (Logger) LoggerFactory.getLogger(SpringLearnApplication.class);

	public static void main(String[] args) throws ParseException {
		SpringApplication.run(SpringLearnApplication.class, args);
		
		logger.info("Main");
		displayDate();
		displayCountry();
		displayCountries();
	}
	
	public static void displayDate() throws ParseException {
		 logger.info("START");
		 ApplicationContext context = new ClassPathXmlApplicationContext("date-format.xml");
		 SimpleDateFormat format = context.getBean("dateFormat",SimpleDateFormat.class);
		 Date date = format.parse("31/12/2018");
		 logger.debug(date.toString());
		 logger.info("END");
	}
	
	public static void displayCountry() {
		logger.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = (Country) context.getBean("in", Country.class);
		Country anotherCountry = context.getBean("us", Country.class);
		logger.debug("Country : {}", country.toString());
		logger.debug("Country : {}", anotherCountry.toString());
		logger.info("END");

	}
	
	public static void displayCountries() {
		logger.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries = (List<Country>) context.getBean("countryList", ArrayList.class);
		logger.debug("Countries : {}", countries.toString());
		logger.info("END");

	}

}
